const HomePage = () => {
  return (
    <>
      <section className="">
        <div className="">
          <p className="">
            Welcome to React
          </p>
        </div>
      </section>
    </>
  );
};

export default HomePage;
